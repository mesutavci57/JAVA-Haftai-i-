
public class HataKontrol5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String yazi=null;
		try {
		System.out.println(yazi.charAt(0));
		}catch(NullPointerException e)
		{
			System.out.println("String tan�ms�z oldu�u i�in metodu �a��ramazs�n�z");
		}
	
	}

}
