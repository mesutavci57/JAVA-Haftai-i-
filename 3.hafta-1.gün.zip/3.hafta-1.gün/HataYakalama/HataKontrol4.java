
public class HataKontrol4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="1a";
		try {
		int sayi=Integer.parseInt(s);
		}catch(NumberFormatException e) {
			System.out.println("String,integer a �evrilirken hata olu�tu");
		}
		
	}

}
