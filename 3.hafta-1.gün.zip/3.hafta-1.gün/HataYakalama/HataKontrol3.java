
public class HataKontrol3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sayi1=5,sayi2=0;
		try {
			int bolme=sayi1/sayi2;
			System.out.println(bolme);
		}catch(ArithmeticException e)
		{
			System.out.println("S�f�ra B�lme Hatas�");
		}
		
	}

}
