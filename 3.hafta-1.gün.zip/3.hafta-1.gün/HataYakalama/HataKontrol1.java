import java.util.InputMismatchException;
import java.util.Scanner;

public class HataKontrol1 {

	public static void main(String[] args)
	{
		try
		{
		Scanner s=new Scanner(System.in);
		int sayi=s.nextInt();
		}catch(InputMismatchException e)//Olabilecek t�m hatalar� alg�la
		{
			System.out.print("int haricinde farkl� bir t�rde veri girdiniz");
		}
		
		/* try hata olu�abilme ihtimali olan kodlar�n eklendi�i kod blo�udur 
		 * catch belirli hata t�r�ne g�re,ilgili hatan�n al�nmas� durumunda �al��acak kod blo�udur.
		 * catch birden fazla �retilebilir.Tek �art catch blo�undaki hata s�n�f�n�n ismi farkl� olmak zorundad�r.
		 * 
		 * finaly iste�e ba�l� olarak eklenen bloktur catch sonras�nda eklenir.hata olsada olmasada
		 * �al��acak kod blo�udur.
		 * 
		 * Olabilecek t�m hatalar� yakalayabilmek i�in Exception s�n�f� kullan�l�r.
		 * */
	}
}
