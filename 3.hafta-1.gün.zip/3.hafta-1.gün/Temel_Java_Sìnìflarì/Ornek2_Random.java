import java.util.Random;

public class Ornek2_Random {
	public static int sayiUret(int maxInt)
	{
		Random rnd=new Random();
		return rnd.nextInt(maxInt);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int sayi1=sayiUret(20);
	int sayi2=sayiUret(10);
	if(sayi1>sayi2)
	{
		System.out.println("Say�1 b�y�kt�r "+"Say�1="+sayi1+" Say�2="+sayi2);
	}
	else if(sayi2>sayi1)
	{
		System.out.println("Say�2 b�y�kt�r "+"Say�1="+sayi1+" Say�2="+sayi2);
	}
	else
	{
		System.out.println("�ki say�da birbirine e�ittir "+"Say�1="+sayi1+" Say�2="+sayi2);
	}
	}

}
