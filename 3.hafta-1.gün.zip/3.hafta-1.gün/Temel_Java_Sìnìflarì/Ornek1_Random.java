import java.util.Random;

public class Ornek1_Random {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rnd=new Random();/* random s�n�f� rastgele bir say� d�nd�rebilmek i�in kullan�lan s�n�ft�r.*/
		int sayi=rnd.nextInt(10);
		System.out.println(sayi);

	}

}
