
public class Ornek5_Tarih�slemleri {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
