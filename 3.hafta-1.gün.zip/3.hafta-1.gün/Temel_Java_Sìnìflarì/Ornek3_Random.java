import java.util.Random;
import java.util.Scanner;

public class Ornek3_Random {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		Random rnd=new Random();
		int tsayi=rnd.nextInt(5);
		System.out.println("0-5 aral���nda bir s3ay� giriniz");
		int sayi=s.nextInt();
		if(sayi==tsayi)
		{
			System.out.println("Tebrikler Bildiniz. Tutulan say�="+tsayi);
		}
		else if(sayi>tsayi)
		{
			System.out.println("Girdi�iniz Say� tutulan say�dan b�y�kt�r.Tutulan say�="+tsayi);
		}
		else if(sayi<tsayi)
		{
			System.out.println("Girdi�iniz say� tutulan say�dan k���kt�r.Tutulan say�="+tsayi);
		}

		
	}

}
