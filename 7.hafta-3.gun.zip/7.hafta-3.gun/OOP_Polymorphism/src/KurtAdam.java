
public class KurtAdam extends Adam implements Kurt{

	@Override
	public void ulu() {
		// TODO Auto-generated method stub
		System.out.println("Ulumaya ba�la");
	}

	@Override
	public void kos() {
		// TODO Auto-generated method stub
		System.out.println("Ko�");
	}

	@Override
	public void saldir() {
		// TODO Auto-generated method stub
		System.out.println("Sald�r");
	}

	@Override
	public void penceAt() {
		// TODO Auto-generated method stub
		System.out.println("Pen�e At");
		
	}

	@Override
	public void kuyrukSalla() {
		// TODO Auto-generated method stub
		System.out.println("Kuyruk salla");
		
	}

}
