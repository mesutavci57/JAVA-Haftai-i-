
public class KurtAdamDeneme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		KurtAdam kurtAdam=new KurtAdam();
		kurtAdam.agla();
		kurtAdam.dusun();
		kurtAdam.konus();
		kurtAdam.giyin();
		kurtAdam.kos();
		kurtAdam.penceAt();
		kurtAdam.saldir();
		kurtAdam.ulu();
		kurtAdam.yuru();
		kurtAdam.kuyrukSalla();
	}

}
