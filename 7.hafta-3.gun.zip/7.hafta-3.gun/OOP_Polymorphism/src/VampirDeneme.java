
public class VampirDeneme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vampir dracula=new Vampir();
		dracula.konus();
		dracula.isir();
		dracula.sarkiSoyle();
		dracula.uc();
		dracula.yuru();
		
	}

}
