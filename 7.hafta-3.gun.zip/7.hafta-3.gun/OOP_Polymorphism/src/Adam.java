
public class Adam {
public void konus()
{
	System.out.println("Konu�");
}
public void dusun()
{
	System.out.println("D���n");
}
public void yuru()
{
	System.out.println("Y�r�");
}
public void giyin()
{
	System.out.println("Giyin");
}
public void agla()
{
	System.out.println("A�la");
}
}
