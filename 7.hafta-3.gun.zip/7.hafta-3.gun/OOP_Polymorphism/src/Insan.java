
public class Insan {
public void yuru()
{
	System.out.println("Y�r�d�");
}
public void konus()
{
	System.out.println("Konu�tu");
}
public void sarkiSoyle()
{
	System.out.println("�ark� s�yledi");
}
}
