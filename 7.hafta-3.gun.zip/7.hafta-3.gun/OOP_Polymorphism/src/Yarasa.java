
public interface Yarasa {
	public void uc();
	public void isir();

}
