
public class Vampir extends Insan implements Yarasa{

	@Override
	public void uc() {
		// TODO Auto-generated method stub
		System.out.println("U�tu");
	}

	@Override
	public void isir() {
		// TODO Auto-generated method stub
		System.out.println("Is�rd�");
		
	}

}
