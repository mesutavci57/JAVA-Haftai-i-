
public abstract class Isci {

}
