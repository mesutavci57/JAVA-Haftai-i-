
public abstract class Araba {
public void arabaPlaka(String plaka)
{
	System.out.println("Araban�n Plakas�="+plaka);
}
}
