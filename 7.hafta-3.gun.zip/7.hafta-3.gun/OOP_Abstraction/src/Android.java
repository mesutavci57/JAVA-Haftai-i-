
public abstract class Android {

	public abstract void versionNo(int versionNo);
	public abstract void codeName(String name);
}
