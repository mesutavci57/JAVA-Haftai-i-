
public class Telefon extends Android{

	@Override
	public void versionNo(int versionNo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void codeName(String name) {
		// TODO Auto-generated method stub
		
	}

}
