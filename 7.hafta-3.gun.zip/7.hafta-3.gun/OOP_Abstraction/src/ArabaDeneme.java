
public class ArabaDeneme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Araba araba=new Araba();--Abstract s�n�f oldu�u i�in new Araba dan sonra hata verir.
		MotorluTasitlar tasit=new MotorluTasitlar();
		tasit.arabaPlaka("34-FBS-24");
		Araba araba2=new MotorluTasitlar();
		araba2.arabaPlaka("34-DF-234");
	}

}
