
public class Ornek8 {

	
static void carpimTablosu(int sayi)
{
	for (int i = 1; i <=10; i++) {
		System.out.println(i+"x"+sayi+"="+(sayi*1));
	}
}

public static void main(String[]args)
{
	
	for (int i = 1; i<=10; i++) {
		System.out.println(i+"> i�in:");
		carpimTablosu(i);
		System.out.println("---");
	}

}

}
