import java.util.Scanner;

public class Ornek14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int[]dizi=new int[5];
		for (int i = 0; i < dizi.length; i++) {
			System.out.println((i+1)+".say�y� giriniz");
			dizi[i]=s.nextInt();
			
		}
		int gecici=0;
		for (int i = 0; i < dizi.length; i++) {
			for (int j = 0; j < dizi.length; j++) {
				if(dizi[i]>dizi[j])
				{
					gecici=dizi[i];
					dizi[i]=dizi[j];
					dizi[j]=gecici;
				}
				
			}
		}
		for (int i = 0; i < dizi.length; i++) {
			System.out.println(dizi[i]);
		}

	}

}
