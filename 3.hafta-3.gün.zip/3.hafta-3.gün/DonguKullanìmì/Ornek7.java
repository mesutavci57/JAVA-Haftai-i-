
public class Ornek7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Dizi elemanlar�n� for d�ng�s� ile tek tek d�nd�rme

	
		int[] sayiDizisi={1,7,69,45};
		String[] yaziDizisi= {"�STANBUL","ANKARA","�ZM�R","BURSA"};
		for(int i=0;i<sayiDizisi.length;i++)
		{
			System.out.println(sayiDizisi[i]);
		}
		System.out.println("----------");
		for(int j=0;j<yaziDizisi.length;j++)
		{
			System.out.println(yaziDizisi[j]);
		}
		System.out.println("-------------");
		//Foreach d�ng�s� ile iterasyon
		for(int gecici:sayiDizisi)
		{
			System.out.println(gecici);
		}
		System.out.println("-------------");
		for(String yazi:yaziDizisi)
		{
			System.out.println(yazi);
		}
	}
	
	

}
