import java.util.Random;

public class Ornek11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[]sayilar=new int[10];
		Random rnd=new Random();
		for (int i=0;i<10;i++)
		{
			sayilar[i]=rnd.nextInt();
		}
		for(int j=0;j<10;j++)
		{
			if(sayilar[j]%2==0)
			{
				System.out.println("�ift Say�= "+sayilar[j]);
			}
			else
			{
				System.out.println("Tek Say�= "+sayilar[j]);
			}
		}

	}

}
