import java.util.Scanner;

public class Ornek10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Ka� adet say� girilecek");
		int n=s.nextInt();
		int[]sayi=new int[n];
		for (int i = 0; i<n; i++) {
			System.out.println("Say� gir");
			sayi[i]=s.nextInt();
		}
		int toplam=0;
		for(int j=0;j<n;j++)
		{
			toplam+=sayi[j];
		}
		System.out.println("T�m say�lar�n toplam�="+toplam); 
	}

}
