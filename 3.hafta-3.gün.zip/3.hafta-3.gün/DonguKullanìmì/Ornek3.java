import java.util.Scanner;

public class Ornek3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int sinir,artis;
		System.out.println("Ka�a kadar say�ls�n?");
		sinir=s.nextInt();
		System.out.println("Art�� miktar�n� giriniz");
		artis=s.nextInt();
		for(int i=0;i<=sinir;i+=artis)
		{
			System.out.println(i);
		
		}
	}

}
