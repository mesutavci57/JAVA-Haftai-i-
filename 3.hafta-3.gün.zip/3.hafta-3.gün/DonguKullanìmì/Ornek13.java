import java.util.Scanner;

public class Ornek13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String unluler="ae�io�u�";
		Scanner s=new Scanner(System.in);
		String kelime=s.next();
		int sayi=0;
		for(int i=0;i<kelime.length();i++)
		{
			for(int j=0;j<unluler.length();j++)
			{
				if(kelime.charAt(i)==unluler.charAt(j))
				{
					sayi++;
				}
			}
		
		}
		System.out.println("�nl� harf say�s�="+sayi);
	}

}
