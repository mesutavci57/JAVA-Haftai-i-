
public class Ornek9 {

	static void piramitUret(char karakter)
	{
		for(int a=10;a>0;a--)
		{
			int b;
			for(b=0;b<a;b++)
			{
				System.out.print(" ");}
				for(int j=b;j<10;j++)
				{
					System.out.print(karakter+" ");
				}
				System.out.println("");
			}
		}
	
	static void sayiPiramitUret(int uzunluk)
	{
		for(int i=0;i<=uzunluk;i++)
		{//0 dan 10 a kadar d�n
			for(int j=0;j<=uzunluk-i;j++)//bo�luklar� �ret
			{
				System.out.print(" ");
			}
		for(int k=0;k<=i;k++)
		{
			System.out.print(k+" ");
		}
		System.out.println("");
	}
	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	piramitUret('*');
	System.out.println("-------------");
	piramitUret('@');
	System.out.println("-------------");
	piramitUret('#');
	System.out.println("-------------");
	sayiPiramitUret(10);
	}

}
