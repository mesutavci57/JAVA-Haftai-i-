import java.util.Scanner;

public class Ornek12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Kelime giriniz");
		String kelime=s.nextLine();
		for(int i=0;i<kelime.length();i++)
		{
			if(kelime.charAt(i)!='A'&&kelime.charAt(i)!='a')
			{
				System.out.print(kelime.charAt(i));
			}
		}
	}

}
