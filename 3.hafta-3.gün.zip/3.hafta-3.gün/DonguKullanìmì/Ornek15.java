
public class Ornek15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[]dizi=new String[3];
		dizi[0]="merhaba";
		dizi[1]="100";
		dizi[2]="Java8";
		int[]intDizi=new int[3];
		String sayilar="0123456789";
		//dizinin elemanlar�n� tek tek gezebilmek i�in
		for (int i = 0; i < dizi.length; i++) {
			int gecici=0;
			//dizinin indisinde bulunan stringin t�m karakterlerini gezebilmek i�in �rettik
			for (int j = 0; j < dizi[i].length(); j++) {
				for (int k = 0; k < intDizi.length; k++) {
					if(dizi[i].charAt(j)==sayilar.charAt(k))
					gecici++;
				}
				if(dizi[i].length()==gecici)
				{
					System.out.println(dizi[i]+" numeriktir");
				}
			}
		}
	}

}
