import java.io.File;
import java.io.IOException;

public class Ornek3 {
	public static void dosyaUret(String path,int uretilecekDosyaSayisi)
	{
		for (int i = 0; i <uretilecekDosyaSayisi; i++) {
			File f=new File(path);
			try
			{
			f.createNewFile();	
			}catch(IOException e)
			{
				e.printStackTrace();
			}
			
		}
	}
	public static void dosyalariSil(String path)
	{
		File dosya=new File(path);
		File[]dosyalar=dosya.listFiles();
		for (int i = 0; i < dosyalar.length; i++) {
			dosyalar[i].delete();
			
		}
	}
	public static void dosyaListele(String path)
	{
		File dosya=new File(path);
		File[]dosyalar=dosya.listFiles();
		for (int i = 0; i < dosyalar.length; i++) {
			System.out.println(dosyalar[i].getName());
			
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		dosyaUret("Z:/ismek",20);
		//dosyalariSil("Z:/ismek");
		dosyaListele("Z:/ismek");

	}

}
