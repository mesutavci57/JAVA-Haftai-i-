import java.io.File;

public class Ornek2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f=new File("Z:/ismek");
		
		if(f.mkdir())
		{
			System.out.println("Klas�r �retildi");
		}
		else
		{
			System.out.println("Klas�r �retilemedi");
		}

	}

}
