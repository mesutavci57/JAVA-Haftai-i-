import java.io.File;
import java.io.IOException;

public class Ornek1 {

	public static void main(String[] args) {
		//File s�n�f� metotlar�
		File dosya=new File("Z:/mesutavci.txt");//z> mesutavci klos�r�n� �al��mak ama�l� baz al�r(Konumu i�aret eder).
		try {
		boolean dosyaUretildiMi=dosya.createNewFile();
		if(dosyaUretildiMi)
		{
			System.out.println("z diski i�inde mesutavci dosyas� �retildi");
		}
		else
		{
			System.out.println("z diski i�inde mesutavci dosya �retilemedi");//false d�nerse sebebi z diski bulunmad��� i�in olabilir yada bu isimde ba�ka bir dosya olabilir
		}
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		/*
		 * canExecute
		 * canRead
		 * canWrite
		 * delete
		 * exists
		 * createNewFile
		 * getAbsolutePath
		 * isHidden
		 * isDirectory
		 * isFile
		 * list
		 * length
		 * mkDir
		 */
		
	}

}
