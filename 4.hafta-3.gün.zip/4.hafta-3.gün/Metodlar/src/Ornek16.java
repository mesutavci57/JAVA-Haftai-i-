import java.util.Scanner;

public class Ornek16 {
public String tersineCevir(String kelime)
{
	String gecici="";
	for(int i=kelime.length()-1;i>-1;i--)
	{
	gecici+=kelime.charAt(i);
	}
	return gecici;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Bir kelime giriniz");
		String kelime=s.next();
		Ornek16 o=new Ornek16();
		System.out.println(o.tersineCevir(kelime));
	}

}
