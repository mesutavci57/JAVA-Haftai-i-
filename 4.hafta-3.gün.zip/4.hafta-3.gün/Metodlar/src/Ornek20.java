import java.time.LocalDate;
import java.util.Scanner;

public class Ornek20 {
	public LocalDate tarih;
public String emeklilikTarihHesapla(int dt,int ibt,String cinsiyet,int prim)
{
	tarih=LocalDate.now();
	String mesaj="";
	int suankiYil=tarih.getYear();
	int yas=suankiYil-dt;
	//kad�nlar i�in ya� �art� 60
	//erkekler i�in ya� �art� 65
	if("erkek".equalsIgnoreCase(cinsiyet))
	{
		if(prim>3600) {
			if(yas>=65)
			{
			mesaj="Tebrikler emekli olmaya hak kazand�n�z.Ya��n�z:"+yas+"Prim g�n say�s�:"+prim;
			}
			else
			{
			mesaj="Prim g�n say�n�z yeterli fakat,65 ya��n� beklemeniz gerekmektedir";
			}
		}
		else
		{
			mesaj="Prim g�n say�n�z yetersizdir.En az 3600 �al��ma g�n� ve 65 ya� gereklidir";
		}
	
	}
	else if("kad�n".equalsIgnoreCase(cinsiyet))
	{
		if(prim>3600)
		{
			if(yas>=60)
			{
				mesaj="Tebrikler emekli olmaya hak kazand�n�z.Ya��n�z:"+yas+"Prim g�n say�s�:"+prim;
			}
			else
			{
				mesaj="Prim g�n say�n�z yeterli fakat,60 ya��n� beklemeniz gerekmektedir";
			}
		}
		else
		{
			mesaj="Prim g�n say�n�z yetersizdir.En az 3600 �al��ma g�n� ve 60 ya� gereklidir";
		}
	}
	return mesaj;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//dogumy�l�,i�e ba�lang�� y�l�,prim,cinsiyet
		Scanner s=new Scanner(System.in);
		System.out.println("do�um y�l�n�z� giriniz");
		int dt=s.nextInt();
		System.out.println("��e giri� y�l�n�z� giriniz");
		int ibt=s.nextInt();
		System.out.println("Cinsiyetinizi giriniz");
		String cinsiyet=s.next();
		System.out.println("Prim g�n say�s�n� giriniz");
		int prim=s.nextInt();
		Ornek20 o=new Ornek20();
		System.out.println(o.emeklilikTarihHesapla(dt, ibt, cinsiyet,prim));
		
	}

}
