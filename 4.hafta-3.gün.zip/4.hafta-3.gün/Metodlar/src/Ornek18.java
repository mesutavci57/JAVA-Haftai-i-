import java.util.Scanner;

public class Ornek18 {
	public double urunFiyat(int urun)
	{
		int urunfiyat=0;
		double kdv=0;
		switch(urun)
		{
		case 1:urunfiyat=50;kdv=1.18;break;
		case 2:urunfiyat=75;kdv=1.08;break;
		case 3:urunfiyat=100;kdv=1.18;break;
		default:urunfiyat=50;kdv=1.18;break;
		}
		double tutar=urunfiyat*kdv;
		return tutar;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("�r�n se�iniz");
		System.out.println("1-G�mlek");
		System.out.println("2-Pantolon");
		System.out.println("3-Ayakkab�");
		int urun=s.nextInt();
		double kdv;
		Ornek18 o=new Ornek18();
		System.out.println(o.urunFiyat(urun));

	}

}
