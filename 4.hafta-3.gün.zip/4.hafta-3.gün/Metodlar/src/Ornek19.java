import java.util.Scanner;

public class Ornek19 {
public double kurHesapla(double birimFiyati,double kurMiktari)
{
	double sonuc=(birimFiyati*kurMiktari);
	return sonuc;
}
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Kur birim fiyat� giriniz");
		double kurBirimFiyati=s.nextDouble();
		System.out.println("Kur miktar�n� giriniz");
		double kurMiktari=s.nextDouble();
		Ornek19 o=new Ornek19();
		System.out.println(o.kurHesapla(kurBirimFiyati, kurMiktari)+" TL");
		
	}

}
