
public class Ornek17 {
public double maasHesapla(double maas,int calisantipi,int saat)
{
	double ucret=0;
	ucret=ucret+maas;
	if(saat>=40)
	{
		ucret=ucret+100;
	}
	else if(calisantipi==2)
	{
		
	}
	switch(calisantipi)
	{
	case 1:
		ucret=ucret*1.02;
		break;
	case 2:
		ucret=ucret*1.05;
		break;
	case 3:
		ucret=ucret*1.10;
		break;
		
	case 4:
		ucret=ucret*1.50;
		break;
	}
	return ucret;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ornek17 o=new Ornek17();
		System.out.println(o.maasHesapla(200,4,40));

	}

}
