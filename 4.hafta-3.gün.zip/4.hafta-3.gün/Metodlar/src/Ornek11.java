import java.util.Scanner;

public class Ornek11 {
	
	public double hesapla(int x,int y,String islem)
	{
		double hesap = 0;
		if("toplama".equalsIgnoreCase(islem))
		{
			hesap=x+y;
			
		}
		else if("��karma".equalsIgnoreCase(islem))
		{
			hesap=x-y;
			
		}
		else if("�arpma".equalsIgnoreCase(islem))
		{
			hesap=x*y;
			
		}
		else if("bolme".equalsIgnoreCase(islem))
		{
			hesap=x/y;
			
		}
		return hesap;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("a say�s�n� giriniz");
		int a=s.nextInt();
		System.out.println("b say�s�n� giriniz");
		int b=s.nextInt();
		System.out.println("Hangi i�lem yap�lacak");
		String islem=s.next();
		Ornek11 o=new Ornek11();
		System.out.println(o.hesapla(a, b, islem));
		
	}

}
