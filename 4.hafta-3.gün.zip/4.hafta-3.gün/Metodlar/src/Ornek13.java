import java.util.Scanner;

public class Ornek13 {
	public String notHesapla(double vize,double fin)
	{
		String harfNotu="";
		double ortalama=(vize*0.4)+(fin*0.6);
		if(ortalama <70)
		{
			harfNotu="FF";
		}
		else if(ortalama>10&&ortalama<=20)
		{
			harfNotu="FD";
		}
		else if(ortalama>20&&ortalama<=30)
		{
			harfNotu="DD";
		}
		else if(ortalama>30&&ortalama<=40)
		{
			harfNotu="DC";
		}
		else if(ortalama>40&&ortalama<=50)
		{
			harfNotu="CC";
		}
		else if(ortalama>50&&ortalama<=60)
		{
			harfNotu="CB";
		}
		else if(ortalama>60&&ortalama<=70)
		{
			harfNotu="BB";
		}
		else if(ortalama>70&&ortalama<=80)
		{
			harfNotu="BA";
		}
		else if(ortalama>80&&ortalama<=90)
		{
			harfNotu="AA";
		}
		return harfNotu;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double finalNotu,vizeNotu;
		Scanner s=new Scanner(System.in);
		System.out.println("Vize notunu giriniz");
		vizeNotu=s.nextDouble();
		System.out.println("Final notunu giriniz");
		finalNotu=s.nextDouble();
		Ornek13 o=new Ornek13();
		String sonuc=o.notHesapla(vizeNotu, finalNotu);
		if("FF".equals(sonuc))
		{
			System.out.println("Kald�n�z l�tfen seneye tekrar deneyin");
		}
		else if("FD".equals(sonuc))
		{
			System.out.println("Kald�n�z l�tfen seneye tekrar deneyin");
		}
		else
		{
			System.out.println("Tebrikler dersi ge�tiniz");
		}
	}

}