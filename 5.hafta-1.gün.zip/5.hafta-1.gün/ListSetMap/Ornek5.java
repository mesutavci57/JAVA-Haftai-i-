import java.util.ArrayList;

public class Ornek5 {
	public static void sehirleriListele(ArrayList<String> sehirler,char ch)
	{
		System.out.println("\n"+ch+" harfi ile ba�layn �ehirleri listeleyelim");
		for(String sehir:sehirler)
		{
			if(sehir.charAt(0)==ch)
			{
				System.out.println(sehir);
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String>sehir=new ArrayList<>();
		sehir.add("�stanbul");
		sehir.add("Ankara");
		sehir.add("Bursa");
		sehir.add("Bolu");
		sehir.add("Antalya");
		sehir.add("�zmir");
		sehirleriListele(sehir,'�');
		sehirleriListele(sehir,'A');
	}

}
