import java.util.ArrayList;

public class Ornek8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Araba>arabalar=new ArrayList<>();
		arabalar.add(new Araba("Fiat-Linea","2010",35000,"k�rm�z�"));
		arabalar.add(new Araba("Volkswagen-Golf","2012",34000,"lacivert"));
		arabalar.add(new Araba("Ford-Focus","2012",25000,"beyaz"));
		for(Araba araba:arabalar)
		{
			System.out.println("Araban�n markas�="+araba.getMarka());
			System.out.println("Araban�n modeli="+araba.getModel());
			System.out.println("Araban�n fiyat�="+araba.getFiyat());
			System.out.println("Araban�n rengi="+araba.getRenk());
			System.out.println("----------------------------");
		}
	}

}
