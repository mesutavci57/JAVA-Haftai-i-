import java.util.ArrayList;
import java.util.Scanner;

public class Ornek2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Ka� adet de�er girilecek");
		int n=s.nextInt();
		ArrayList<String>liste=new ArrayList<>();
		for(int i=0;i<n;i++)
		{
			System.out.println("Kelime gir");
			String kelime=s.next();
			liste.add(kelime);
		}
		for(int i=0;i<n;i++)
		{
			System.out.println(liste.get(i));
		}
	}

}
