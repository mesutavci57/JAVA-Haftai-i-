
public class Ornek1_Kapsulleme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ogrenci o=new Ogrenci();
		o.setAdSoyad("Mesut Avc�");
		o.setOgrenciNo(15);
		o.setBolumYil(2015);
		o.setCinsiyet('E');
		o.setDogumYili(1997);
		o.setOkulAdi("K�rklareli �niversitesi");
		o.setBolumAdi("Bilgisayar Programc�l���");
		o.setOrtalama(3.10);
		System.out.println("�grenci Ad� Soyad�="+o.getAdSoyad());
		System.out.println("��renci Okul Numaras�="+o.getOgrenciNo());
		System.out.println("��renci Okul Ba�lama Tarihi"+o.getBolumYil());
		System.out.println("�grenci Cinsiyeti="+o.getCinsiyet());
		System.out.println("��renci Do�um Y�l�="+o.getDogumYili());
		System.out.println("��renci Okul Ad�="+o.getOkulAdi());
		System.out.println("��renci B�l�m Ad�="+o.getBolumAdi());
		System.out.println("��renci Ortalamas�="+o.getOrtalama());
		System.out.println("-------------------------");
		Ogrenci o2=new Ogrenci("Ahmet �shako�lu",16,2015,'E',1996,"D�zce �niversitesi","Bilgisayar M�hendisli�i",3.2);
		System.out.println("�grenci Ad� Soyad�="+o2.getAdSoyad());
		System.out.println("��renci Okul Numaras�="+o2.getOgrenciNo());
		System.out.println("��renci Okul Ba�lama Tarihi"+o2.getBolumYil());
		System.out.println("�grenci Cinsiyeti="+o2.getCinsiyet());
		System.out.println("��renci Do�um Y�l�="+o2.getDogumYili());
		System.out.println("��renci Okul Ad�="+o2.getOkulAdi());
		System.out.println("��renci B�l�m Ad�="+o2.getBolumAdi());
		System.out.println("��renci Ortalamas�="+o2.getOrtalama());
	}

}
