import java.util.ArrayList;
import java.util.Scanner;

public class Ornek2_Kapsulleme {

	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		ArrayList<Telefon> telefonlar=new ArrayList<>();
		for(int i=0;i<3;i++)
		{
		System.out.println("Telefonun markas�n� giriniz");
		String marka=s.next();
		System.out.println("Telefonun modelini giriniz");
		String model=s.next();
		System.out.println("Telefon rengini giriniz");
		String renk=s.next();
		System.out.println("Telefonun ��letim sistemini giriniz");
		String isletim=s.next();
		System.out.println("Telefonun �retim y�l�n� giriniz");
		int yil=s.nextInt();
		Telefon t=new Telefon(marka,model,renk,isletim,yil);
		telefonlar.add(t);
		}
		for(Telefon tel:telefonlar)
		{
			System.out.println("Telefon markas�="+tel.getMarka());
			System.out.println("Telefonun modeli="+tel.getModel());
		}
	}
}
