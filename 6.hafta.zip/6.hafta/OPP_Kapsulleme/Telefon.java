
public class Telefon {
private String marka;
String model;
String renk;
String isletimSistemi;
int uretimYili;

public Telefon()
{
	
}
public Telefon(String marka, String model, String renk, String isletimSistemi, int uretimYili) {
	super();
	this.marka = marka;
	this.model = model;
	this.renk = renk;
	this.isletimSistemi = isletimSistemi;
	this.uretimYili = uretimYili;
}
public String getMarka() {
	return marka;
}
public void setMarka(String marka) {
	this.marka = marka;
}
public String getModel() {
	return model;
}
public void setModel(String model) {
	this.model = model;
}
public String getRenk() {
	return renk;
}
public void setRenk(String renk) {
	this.renk = renk;
}
public String getIsletimSistemi() {
	return isletimSistemi;
}
public void setIsletimSistemi(String isletimSistemi) {
	this.isletimSistemi = isletimSistemi;
}
public int getUretimYili() {
	return uretimYili;
}
public void setUretimYili(int uretimYili) {
	this.uretimYili = uretimYili;
}
}
