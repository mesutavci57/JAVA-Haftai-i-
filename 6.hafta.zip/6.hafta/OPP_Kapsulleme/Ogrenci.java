
public class Ogrenci {
	private String adSoyad;
	private double ogrenciNo;
	private int bolumYil;
	private char cinsiyet;
	private int dogumYili;
	private String okulAdi;
	private String bolumAdi;
	private double ortalama;
	
	public Ogrenci()//Bo� constructor
	{
		
	}
//E�er nesneleri public eri�im seviyesinde yazsayd�k,constructor ve getter/setter metodlara hi� ihtiya� duymazd�k
//Nesneleri �zellikle private olarak belirtiyoruz ki,ilgili nesne de�erine eri�ebilmesi yada de�i�tirebilmesi i�in bir metot kullanmaya zorluyoruz.
//Bu i�i g�venlik mekanizmas�n� artt�rabilmek i�in yap�yoruz.
	public Ogrenci(String adSoyad, double ogrenciNo,int bolumYil,char cinsiyet,int dogumYili,String okulAdi,String bolumAdi,double ortalama)
	{
		this.adSoyad=adSoyad;
		this.ogrenciNo=ogrenciNo;
		this.bolumYil=bolumYil;
		this.cinsiyet=cinsiyet;
		this.dogumYili=dogumYili;
		this.okulAdi=okulAdi;
		this.bolumAdi=bolumAdi;
		this.ortalama=ortalama;
	}
	public void setAdSoyad(String adSoyad)
	{
		this.adSoyad=adSoyad;
	}
	public String GetAdSoyad()
	{
		return this.adSoyad;
	}
	public void SetOgrenciNo(double ogrenciNo)
	{
		this.ogrenciNo=ogrenciNo;
	}
	public double GetOgrenciNo()
	{
		return this.ogrenciNo;
	}
	public void SetBolumYil(int bolumYil)
	{
		this.bolumYil=bolumYil;
	}

	public double getOgrenciNo() {
		return ogrenciNo;
	}

	public void setOgrenciNo(double ogrenciNo) {
		this.ogrenciNo = ogrenciNo;
	}

	public int getBolumYil() {
		return bolumYil;
	}

	public void setBolumYil(int bolumYil) {
		this.bolumYil = bolumYil;
	}

	public char getCinsiyet() {
		return cinsiyet;
	}

	public void setCinsiyet(char cinsiyet) {
		this.cinsiyet = cinsiyet;
	}

	public int getDogumYili() {
		return dogumYili;
	}

	public void setDogumYili(int dogumYili) {
		this.dogumYili = dogumYili;
	}

	public String getOkulAdi() {
		return okulAdi;
	}

	public void setOkulAdi(String okulAdi) {
		this.okulAdi = okulAdi;
	}

	public String getBolumAdi() {
		return bolumAdi;
	}

	public void setBolumAdi(String bolumAdi) {
		this.bolumAdi = bolumAdi;
	}

	public double getOrtalama() {
		return ortalama;
	}

	public void setOrtalama(double ortalama) {
		this.ortalama = ortalama;
	}

	public String getAdSoyad() {
		return adSoyad;
	}
	
}
