import java.util.Scanner;

public class Ornek5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("kelime gir");
		String kelime=s.nextLine();
		for(int i=0;i<kelime.length();i++)
		{
			System.out.println(kelime.charAt(i));
		}
	}

}
