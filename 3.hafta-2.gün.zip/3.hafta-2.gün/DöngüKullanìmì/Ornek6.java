import java.util.Scanner;

public class Ornek6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Ka� adet kelime girilecek?");
		int n=s.nextInt();
		String[]kelimeler=new String[n];
		for(int i=0;i<n;i++)
		{
			kelimeler[i]=s.next();
		}
		for(int j=0;j<n;j++)
		{
			System.out.print(kelimeler[j].charAt(0));
		}
	}

}
