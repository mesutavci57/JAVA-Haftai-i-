import java.util.Scanner;

public class Ornek4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		String[]kelime=new String[5];
		for(int i=0;i<5;i++)
		{
			System.out.println((i+1)+".eleman� giriniz");
			kelime[i]=s.next();
		}
		for(int j=0;j<5;j++)
		{
			System.out.println(kelime[j]);
		}
	}

}
