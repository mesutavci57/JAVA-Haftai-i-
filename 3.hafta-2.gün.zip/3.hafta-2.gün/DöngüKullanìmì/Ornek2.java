
public class Ornek2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//0 dan ba�lay�m 5 e kadar olan say�lar� yazd�rmak
		//Birer birer artt�rmak
		for(int i=0;i<=4;i++)
		{
			System.out.println(i);
		}
		System.out.println("-----------------");
		//iki�er iki�er artt�rmak
		for(int k=0;k<=20;k+=2)
		{
			System.out.println(k);
		}
		System.out.println("-----------------");
		for(int j=100; j>=50;j-=2)
		{
			System.out.println(j);
		}
		
		//sonsuz d�ng�
		for(;;)
		{
			System.out.println("merhaba");
		}
		//sonsuz d�ng�y� sonland�rmak
		int a=0;
		for(;;)
		{
			a++;
			System.out.println("merhaba");
			if(a==20)
			{
				break;
			}
		}
		
		//belirtti�imiz say� kadar artt�rma
		int artisMiktari=4;
		for(int i=0;i<=500;i+=artisMiktari)
		{
			if(i==200)
			{
				artisMiktari=4;
			}
			System.out.println(i);
		}
		//belirtti�imiz sayi kadar �arpma
		for(int i=1;i<=500;i*=5)
		{
			System.out.println(i);
		}
		
		
	}

}
