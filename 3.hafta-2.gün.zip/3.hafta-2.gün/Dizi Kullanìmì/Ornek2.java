import java.util.Scanner;

public class Ornek2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		String[]kelimeler=new String[3];
		System.out.println("Kelime gir");
		kelimeler[0]=s.next();
		System.out.println("Kelime gir");
		kelimeler[1]=s.next();
		System.out.println("Kelime gir");
		kelimeler[2]=s.next();
	
		System.out.println(kelimeler[0]);
		System.out.println(kelimeler[1]);
		System.out.println(kelimeler[2]);
		
	}

}
