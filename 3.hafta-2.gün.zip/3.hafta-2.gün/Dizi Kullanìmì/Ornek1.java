
public class Ornek1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[]sayilar=new int[5];
		sayilar[0]=1;
		sayilar[1]=4;
		sayilar[2]=8;
		sayilar[3]=4;
		sayilar[4]=60;
		System.out.println(sayilar[0]);
		System.out.println(sayilar[1]);
		
		//Dizi olu�turma
		String[]yazilar=new String[4];
		
		//diziye elmana/de�er atama
		yazilar[0]="�SMEK";
		yazilar[1]="FAT�H";
		yazilar[2]="B�L���M";
		yazilar[3]="OKULU";
		
		//dizi eleman� �a��rma
		System.out.println(yazilar[2]+" "+yazilar[3]);
		
		

	}

}
