
public class Ornek4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int dizilerde dizinin eleman�na de�er girilmezse de�eri 0 d�r
		int[]sayilar =new int[3];
		sayilar[2]=100;
		System.out.println(sayilar[0]);
		System.out.println(sayilar[1]);
		System.out.println(sayilar[2]);
		//string dizilerde dizinin eleman�na de�er girlmezse de�eri null dur.
		String[] kelimeler=new String[3];
		kelimeler[1]="merhaba";
		System.out.println(kelimeler[0]);
		System.out.println(kelimeler[1]);
		System.out.println(kelimeler[2]);
	}

}
