
public class Ornek3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object[] obj=new Object[3];
		obj[0]=5;
		obj[1]="Merhaba";
		obj[2]=10.3d;
		System.out.println(obj[0]);
		System.out.println(obj[1]);
		System.out.println(obj[2]);
		
		//int dizilerde dizinin eleman�na de�er girilmezse de�eri 0 d�r
		//string dizilerde dizinin eleman�na de�er girlmezse de�eri null dur.
	}

}
