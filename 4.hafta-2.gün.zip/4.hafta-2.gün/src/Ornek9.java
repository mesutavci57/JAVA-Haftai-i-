import java.util.Scanner;

public class Ornek9 {
	public void sayilariDon(int bas,int bit,String tekmi)
	{
			if("tek".equalsIgnoreCase(tekmi))
			{
				for(int i=bas;i<bit;i++)
				{
					if(i%2==1)
					{
						System.out.println(i);
					}
				}
			}
			else if("�ift".equalsIgnoreCase(tekmi))
			{
				for(int i=bas;i<bit;i++)
				{
					if(i%2==0)
					{
						System.out.println(i);
					}
				}
			}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ornek9 o=new Ornek9();
		Scanner s=new Scanner(System.in);
		System.out.println("Ba�lang�� de�erini giriniz");
		int bas=s.nextInt();
		System.out.println("Biti� de�erini yaz�n�z");
		int bts=s.nextInt();
		System.out.println("Tek say�lar m� girilsin yoksa �ift say�lar m�?");
		String karar=s.next();
		o.sayilariDon(bas, bts, karar);
	
	}

}
