import java.util.Scanner;

public class Ornek12 {

	public String buyukKucuk(String kelime1)
	{
		String karakter="";
		for(int i=0;i<kelime1.length();i++)
		{
			if(i%2==0)
			{
				karakter=""+kelime1.charAt(i);
				System.out.print(karakter.toLowerCase());
			}
			else
			{
				karakter=""+kelime1.charAt(i);
				System.out.print(karakter.toUpperCase());
			}
		}
		return karakter;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Kelime giriniz");
	    String kelime=s.next();
		Ornek12 o=new Ornek12();
		o.buyukKucuk(kelime);
	}

}
