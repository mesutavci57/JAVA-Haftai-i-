import java.util.Scanner;
//DI�ARIDAN  YAZI G�R�P BUNLARIN ���NDE KA� TANE BEL�RTT���M�Z KARAKTER SAYISINI BULMA
public class Ornek14 {
	public int karakterSay�s�(String[] str,char karakter){
		int sayi=0;
		for(int i=0;i<str.length;i++)
		{
			for (int j = 0; j < str[i].length(); j++) {
				if(str[i].charAt(j)==Character.toUpperCase(karakter)||str[i].charAt(j)==Character.toLowerCase(karakter))
				{
					sayi++;
				}
			}		}
		return sayi;
	}
	public int karakterSayisi(String str,char harf)
	{
		int sonuc=0;
		for (int i = 0; i < str.length(); i++) {
			if(str.charAt(i)==Character.toUpperCase(harf)||str.charAt(i)==Character.toLowerCase(harf))
			{
				sonuc++;
			}
			
			
		}
		return sonuc;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		String[]dizi=new String[5];
		for (int i = 0; i < dizi.length; i++) {
			dizi[i]=s.next();
			
		}
		Ornek14 o=new Ornek14();
		System.out.println("Karakter giriniz");
		char harf=s.next().charAt(0);
		int toplamSayi=o.karakterSay�s�(dizi,harf);
		System.out.println("Dizi elemanlar�nda toplam: "+toplamSayi+" adet "+harf+" bulunmaktad�r");
	}

}
