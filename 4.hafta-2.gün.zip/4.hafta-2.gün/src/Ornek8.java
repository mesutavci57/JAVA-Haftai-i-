import java.util.Scanner;

public class Ornek8 {

	public  double alan(double uzunkenar,double kisakenar)
	{
		return uzunkenar*kisakenar;
	}
	public  double cevre(double uzunkenar,double kisakenar)
	{
		return 2*(uzunkenar+kisakenar);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Uzun kenar� giriniz");
		double uzun=s.nextDouble();
		System.out.println("K�sa kenar� giriniz");
		double kisa=s.nextDouble();
		Ornek8 o=new Ornek8();
		System.out.println("Dikd�rtgenin Alan�="+o.alan(uzun, kisa));
		System.out.println("Dikd�rtgenin �evresi="+o.cevre(uzun, kisa));

	}

}
