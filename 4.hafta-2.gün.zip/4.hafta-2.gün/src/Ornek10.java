import java.util.Scanner;

public class Ornek10 {
	public void doWhile(int bitis)
	{
		int i=0;
		do
		{
			System.out.println(i);
			i++;
		}while(i<bitis);
	}
	public void forDongusu(int bitis)
	{
		for(int i=0;i<bitis;i++)
		{
			System.out.println(i);
		}
	}
	public void whileDongusu(int bitis)
	{
		int i=0;
		while(i<bitis)
		{
			System.out.println(i);
			i++;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ornek10 o=new Ornek10();
		Scanner s=new Scanner(System.in);
		System.out.println("Biti� de�erini giriniz");
		int bitis=s.nextInt();
		o.doWhile(bitis);
		o.forDongusu(bitis);
		o.whileDongusu(bitis);
	}

}
