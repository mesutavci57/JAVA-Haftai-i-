import java.util.Scanner;

public class Ornek15 {
	public int harfleriSay(char[] ch,char karakter)
	{
		int sonuc=0;
	for (int i = 0; i < ch.length; i++) {
		if(ch[i]==karakter)
		{
			sonuc++;
		}
	}
	return sonuc;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * D��ar�dan 5 adet string isteyip diziye at�n.ilgili stringlerin ilk harfini bir char[] de saklay�n
		 * char[] i�inde olan elemanlar�n hepsini bir stringde birle�tirin.
		 * birle�tirdi�iniz string i�inde bir karakteri aray�n.
		 */
		Scanner s=new Scanner(System.in);
		char[]dizi=new char[5];
		for (int i= 0; i < dizi.length; i++) {//D��ar�dan 5 kelime girip char dizisine ilk karakterlerini aktard�k
			System.out.println("Kelime giriniz");
			dizi[i]=s.next().charAt(0);
		}
		String yeni="";
		for (int i = 0; i < dizi.length; i++) {
			yeni+=dizi[i];
		}
		System.out.println("�retilen yeni metin="+yeni);
		Ornek15 o=new Ornek15();
		System.out.println("Bir karakter giriniz");
		char ch=s.next().charAt(0);
		int sayi=o.harfleriSay(dizi, ch);
		System.out.println("Karakterin say�s�="+sayi);
	}

}
