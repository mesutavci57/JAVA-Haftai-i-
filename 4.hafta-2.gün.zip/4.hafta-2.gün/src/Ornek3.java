
public class Ornek3 {
	public void sayiSaydir(int basla,int bitis,int artisMiktari)
	{
		for(int i=basla;i<bitis;i+=artisMiktari)
		{
			System.out.println(i);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ornek3 o=new Ornek3();
		o.sayiSaydir(1,50,5);
	}

}
