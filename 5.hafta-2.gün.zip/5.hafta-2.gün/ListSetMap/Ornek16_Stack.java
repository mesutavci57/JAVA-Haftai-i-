import java.util.Stack;

public class Ornek16_Stack {

	public static void main(String[] args) {
		Stack stack=new Stack();
		stack.add("MECL�S�");
		stack.add("M�LLET");
		stack.add("B�Y�K");
		stack.add("T�RK�YE");
		System.out.println(stack);

	}

}
