import java.util.Stack;

public class Ornek14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack liste=new Stack();
		liste.add("eleman1");
		liste.add("eleman2");
		liste.add("eleman3");
		//stack s�n�f� vector s�n�f�ndan t�remi�tir.Bu nedenle stack s�n�f� i�erisinde vectorda bulunan metot isimleriyle kar��la��labilir.
		//fakat vector de olmay�p stack de bulunan ayr�ca eklenmi� metotlar bulabilirsin.
		
		/*stack metotlar�
		 * add
		 * addElement
		 * capacity
		 * elements
		 * elementsAt
		 * empty
		 * firstElement
		 * lastElement
		 * get
		 * isEmpty
		 * lastIndexOf
		 * indexOf
		 * clear
		 * 
		 * peek--stack in en �st�ndeki ��eyi de�er olarak al�r; ama onu stackten almaz, yerinde b�rak�r. 
		 * pop--stack  en �st�ndeki ��eyi de�er olarak al�r ve onu y���ttan siler. 
		 * push--Verilen nesneyi stack in �st�ne koyar. 
		 *search--verilen nesnenin stack de ka��nc� ��e oldu�unu s�yler.en alttaki elemandan diye ba�lar.olmayan bir�eyi arat�rsak -1 de�eri d�ner.
		 *empty--Y���t�n bo� olup olmad���n� s�yler. Y���t bo�sa true de�erini verir..
		 * 
		 */
		Stack stack = new Stack();
		 stack.push("Londra");
		 stack.push("Moskova");
		 stack.push("Ankara");
		 stack.push("Paris");
		 stack.push("Viyana");
		 System.out.println(stack);
		 System.out.println(stack.search("Ankara"));
		 System.out.println(stack.peek());
		 System.out.println(stack.pop());
		 System.out.println(stack); 
	}

}
