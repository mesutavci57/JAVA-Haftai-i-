import java.util.Scanner;
import java.util.Vector;

public class Ornek12_Vector {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		Vector<String>vector=new Vector<>();
		for(int i=0;i<5;i++)
		{
			System.out.println("Kelime gir");
			vector.addElement(s.next());
		}
		System.out.println("0-4 aras� say� giriniz");
		int i=s.nextInt();
		vector.remove(i);
		for(String eleman:vector)
		{
			System.out.println(eleman);
		}
	}

}
