
public class Ornek6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String website1="www.google.com";
				if(website1.startsWith("www"))
		{
			System.out.println("aranan kelime bulundu");
			
		}
		else
		{
			System.out.println("aranan kelime bulunamad�");
		}
		if(website1.endsWith("com"))
		{
			System.out.println("aranan kelime bulunamad�");
		}
		else
		{
			
			System.out.println("aranan kelime bulunamad�");
		}

	}

}
