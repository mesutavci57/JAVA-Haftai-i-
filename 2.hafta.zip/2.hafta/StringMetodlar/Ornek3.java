
public class Ornek3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String sehir="YUNAN�STANBULGAR�STAN";
		System.out.println(sehir.substring(5,13));
		String istanbul=sehir.substring(5,13);
		System.out.println(istanbul);
	}

}
