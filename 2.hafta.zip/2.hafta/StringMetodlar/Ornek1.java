
public class Ornek1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String isim="�smek Bili�im Okulu";
		isim.charAt(0);
		isim.concat("ut");
		System.out.println(isim.substring(0,5));
	}

}
