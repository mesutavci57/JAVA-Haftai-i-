
public class Ornek7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String kelime="muvaffakiyetsizlestiricilestiriveremeyebileceklerimizdenmissinizcesine";
		System.out.println(kelime.length());
		String okul="�smek Fatih Bili�im Okulu";
		System.out.println("Karakter uzunlu�u:"+okul.length());
	}

}
