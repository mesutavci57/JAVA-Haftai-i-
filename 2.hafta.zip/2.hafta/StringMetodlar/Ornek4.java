
public class Ornek4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String kelime="Ne Mutlu T�rk�m Diyene";
		if(kelime.contains("T�rk"))
		{
			System.out.println("metininin i�inde t�rk kelimesi vard�r");
		}
		else
		{
			System.out.println("metininin i�inde t�rk kelimesi yoktur");
		}
	}

}
