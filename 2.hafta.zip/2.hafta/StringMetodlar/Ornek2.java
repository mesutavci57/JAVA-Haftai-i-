
public class Ornek2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String ad="�smek Bili�im Okulu";
		System.out.println(ad.toUpperCase());
		System.out.println(ad.toLowerCase());
	}

}
