
public class Ornek8 {

	public static void main(String[] args) {
		String kelime=" Selam�n Aleyk�m ";
		System.out.println(kelime);
		System.out.println(kelime.trim());

	}

}
