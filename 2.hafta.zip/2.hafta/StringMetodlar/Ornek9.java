
public class Ornek9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String kelime="Mesut Akif";
		System.out.println(kelime);
		System.out.println(kelime.replace("Akif", "Avc�"));
	}

}
