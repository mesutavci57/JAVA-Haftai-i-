
public class Ornek5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String sehir="�stanbul";
		String baskent="ankara";
			if("istanbul".equals(sehir)){
					System.out.println("�stanbul kelimesi i�eriyor");
			}
			else
			{
				System.out.println("�stanbul kelimesi i�ermiyor");
			}
			if("ANKARA".equalsIgnoreCase(baskent))
			{
				System.out.println("Ankara kelimesi i�eriyor");
			}
			else
			{
				System.out.println("Ankara kelimesi i�ermiyor");
			}
	}

}
