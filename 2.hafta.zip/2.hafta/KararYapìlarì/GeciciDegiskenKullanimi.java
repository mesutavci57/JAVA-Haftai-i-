import java.util.Scanner;

public class GeciciDegiskenKullanimi {
static Scanner s;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		s=new Scanner(System.in);
		int sayi1,sayi2,gecici;
		System.out.println("Say�1 i giriniz");
		sayi1=s.nextInt();
		System.out.println("Sayi2 yi giriniz");
		sayi2=s.nextInt();
		gecici=sayi1;
		sayi1=sayi2;
		sayi2=gecici;
		System.out.println("1.say�:"+sayi1);
		System.out.println("2.say�:"+sayi2);
		
		
	}

}
