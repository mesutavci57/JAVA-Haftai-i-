import java.util.Scanner;

public class Ornek1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*	Ko�ullu ��lemler(Karar Yap�lar�)
		 * 
		 * if
		 * if-else
		 * switch-case
		 */
		Scanner s=new Scanner(System.in);
		System.out.println("L�tfen adon�z� giriniz");
		String adi=s.next();
		System.out.println("Soyad�n�z� giriniz");
		String soyad=s.next();
		if("�erif".equals(adi))//String de�i�kenlerde kar��la�t�rma equals metodu ile yap�l�r.di�er veri tipleri == ile k�yaslan�r.
		{
			System.out.println("merhaba");
		}

	}

}
