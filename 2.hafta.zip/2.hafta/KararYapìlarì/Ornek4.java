import java.util.Scanner;

public class Ornek4 {
	static Scanner s;
	public static void main(String[] args) {
		
		s=new Scanner(System.in);
		String sekil=s.next();
		double alan,cevre;
		if("kare".equals(sekil))
		{
			System.out.println("kenar uzunlu�unu giriniz");
			int a=s.nextInt();
			alan=a*a;
			cevre=4*a;
			System.out.println("Karenin Alan�="+alan);
			System.out.println("Karenin �evresi="+cevre);
		}
		else if("daire".equals(sekil))
		{
			System.out.println("r yi giriniz");
			int r=s.nextInt();
			double pi=3.14d;
			alan=pi*(r*r);
			cevre=2*pi*r;
			System.out.println("Dairenin Alan�="+alan);
			System.out.println("Dairenin �evresi="+cevre);
		}
		else if("dikd�rtgen".equals(sekil))
		{
			System.out.println("k�sa kenar� giriniz");
			int k=s.nextInt();
			System.out.println("uzun kenar� giriniz");
			int u=s.nextInt();
			cevre=2*(k+u);
			alan=u*k;
			System.out.println("Dikd�rtgenin Alan�="+alan);
			System.out.println("Dikd�rtgenin �evresi="+cevre);
		}
		else
		{
			System.out.println("Yanl�� i�lem");
		}
	}

}
