import java.util.Scanner;

public class Ornek10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		String isim=s.next();
		if("ismek".equalsIgnoreCase(isim))
		{
			System.out.println("Giri� ba�ar�l�");//equals ile equalsIgnoreCase ayn� i�i yapar fakat
			//equalsIgnoreCase b�y�k k���k harf ayr�m�n� ortadan kald�r�r.
		}
		else
		{
			System.out.println("Giri� hatal�");
		}
	}

}
