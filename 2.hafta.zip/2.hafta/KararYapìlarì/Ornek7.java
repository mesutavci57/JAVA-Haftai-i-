
public class Ornek7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sayi=5;
		if(sayi==5)
		{
			
		}else
		{
			sayi=5;
		}
		
		//��L� OPERAT�R
		int sayi1=5;
		int sayi2=7;
		int enDusukSayi=(sayi1<sayi2)? sayi1:sayi2;
		System.out.println(enDusukSayi);
		
		//? olan parantezde �art ger�ekle�tirilirse ? sonras� olan k�s�m �al���r �art ger�ekle�mez ise : sonras� olan k�s�m �al���r
		
		boolean okuyorMusun=true;
		String yan�t=okuyorMusun ? "Evet" : "Hay�r";
		System.out.println(yan�t);
	}

}
