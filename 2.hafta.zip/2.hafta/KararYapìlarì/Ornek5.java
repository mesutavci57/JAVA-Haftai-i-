
public class Ornek5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// �� i�e if kullan�m�
		int a=5;
		int b=10;
		if(a+b==15)
		{
			int sonuc=a+b;
			if(sonuc!=10)
			{
				System.out.println("Sonu� 10 de�ildir");
			}
			
		}
		
	}

}
