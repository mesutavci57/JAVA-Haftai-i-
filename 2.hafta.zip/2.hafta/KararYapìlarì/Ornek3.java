import java.util.Scanner;

public class Ornek3 {
static Scanner s;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		s=new Scanner(System.in);
		int a,b,toplam,fark,bol,carp;
		System.out.println("a say�s�n� giriniz");
		a=s.nextInt();
		System.out.println("b say�s�n� giriniz1");
		b=s.nextInt();
		System.out.println("��lemi giriniz");
		String islem=s.next();
		if("toplama".equals(islem))
		{
			System.out.println("Se�ti�iniz i�lem toplama");
			toplam=a+b;
			System.out.println("Toplaman�n Sonucu="+toplam);
		}
		else if("��karma".equals(islem)||"-".equals(islem))
		{
			System.out.println("Se�ti�iniz i�lem ��karma");
			fark=a-b;
			System.out.println("��karman�n Sonucu="+fark);
		}
		else if("�arpma".equals(islem)||"-".equals(islem)||"*".equals(islem))
		{
			System.out.println("Se�ti�iniz i�lem �arpma");
			carp=a*b;
			System.out.println("��karman�n Sonucu="+carp);
		}
		else if("b�lme".equals(islem)||"/".equals(islem))
		{
			System.out.println("Se�ti�iniz i�lem b�lmedir");
			bol=a/b;
			System.out.println("��karman�n Sonucu="+bol);
		}
		else
		{
			System.out.println("Se�ti�iniz i�lem ge�ersiz");
		}
	}

}
