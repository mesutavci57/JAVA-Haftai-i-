import java.util.Scanner;

public class Ornek8 {
static Scanner s;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String mevsim;
		s=new Scanner(System.in);
		System.out.println("Mevsim giriniz");
		mevsim=s.next();
		switch(mevsim) {
		case "sonbahar":System.out.println("Eyl�l");
		System.out.println("Ekim");
		System.out.println("Kas�m");break;
		case "k��":System.out.println("Aral�k");
		System.out.println("Ocak");
		System.out.println("�ubat");break;
		case "ilkbahar":System.out.println("Mart");
		System.out.println("Nisan");
		System.out.println("May�s");break;
		case "yaz":System.out.println("Haziran");
		System.out.println("Temmuz");
		System.out.println("A�ustos");break;
		default:System.out.println("L�tfen mevsim giriniz");break;
		
		}
	}

}
