
public class Ornek11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String metin="MERHABA D�NYA";
		int uzunluk=metin.length();
		for(int i=0;i<metin.length();i++)
		{
			if(metin.charAt(i)!='A')
			{
				System.out.print(metin.charAt(i));
			}
		}
		
	}

}
