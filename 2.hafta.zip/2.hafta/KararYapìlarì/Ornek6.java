import java.util.Scanner;

public class Ornek6 {
	static Scanner s;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		s=new Scanner(System.in);
		System.out.println("Mevsim giriniz");
		String mevsim=s.next();
		if("sonbahar".equals(mevsim))
		{
			System.out.println("Eyl�l");
			System.out.println("Ekim");
			System.out.println("Kas�m");
		}
		else if("k��".equals(mevsim))
		{
			System.out.println("Aral�k");
			System.out.println("Ocak");
			System.out.println("�ubat");
		}
		else if("ilkbahar".equals(mevsim))
		{
			System.out.println("Mart");
			System.out.println("Nisan");
			System.out.println("May�s");
		}
		else if("yaz".equals(mevsim))
		{
			System.out.println("Haziran");
			System.out.println("Temmuz");
			System.out.println("A�ustos");
		}
		else
		{
			System.out.println(" l�tfen mevsim giriniz");
		}
	}

}
