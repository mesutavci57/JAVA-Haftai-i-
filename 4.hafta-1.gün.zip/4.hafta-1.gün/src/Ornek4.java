
public class Ornek4 {
	public void diziYazdir(int[]dizi)
	{
		for(int i=0;i<dizi.length;i++)
		{
			System.out.println(dizi[i]);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ornek4 orn=new Ornek4();
		int[]sayi= {1,2,3,4,5};
		orn.diziYazdir(sayi);
		
	}

}
