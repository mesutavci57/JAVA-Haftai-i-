
public class Ornek1 {
	public void selamVer()
	{
		System.out.println("Selamlar !");
	}
	public int topla(int sayi1,int sayi2)
	{
		int toplam=sayi1+sayi2;
		return toplam;
	}
	public int fark(int sayi1,int sayi2)
	{
		int fark=sayi1-sayi2;
		return fark;
	}
	public int carp(int sayi1,int sayi2)
	{
		int carp=sayi1*sayi2;
		return carp;
	}
	public int bolme(int sayi1,int sayi2)
	{
		int bol=sayi1/sayi2;
		return bol;
	}
	
	
	public static void main(String[] args) {
		/*metod
		 * 
		 * belirli i�lemleri ger�ekle�tiren kod bloklar�d�r.
		 * metodlar�n geri don�� tipleri bulanabildi�i gibi bulunmayadabilir.
		 * e�er bir metot geri de�er d�nd�rmeyecek ise tip olan k�sma void yaz�l�r
		 * void harici bir veri tipi belirtirsek,belirtti�imiz o tipte veri d�nd�rmek zorunday�z
		 * metod geri d�n�� tipi void de�il ise return keywordu metodun en alt sat�r�nda yaz�lmak zorundad�r
		 * return kelimesinden sonra alt sat�rda asla kod yaz�lmaz.
		 * bir metotta return kelimesi sadece 1 defa kullan�labilir.
		 */
		Ornek1 o=new Ornek1();
		o.selamVer();
		System.out.println(o.topla(5,10));
		System.out.println(o.fark(10,6));
		System.out.println(o.carp(5, 7));
		System.out.println(o.bolme(20,5));
	}

}
