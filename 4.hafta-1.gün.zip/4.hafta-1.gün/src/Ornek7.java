import java.util.Scanner;

public class Ornek7 {

	public float alan(float a)
	{
		return (float)a*a;
	}
	public float cevre(float a)
	{
		return (float)4*a;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("a kenar�n� girin");
		float a=s.nextFloat();
		Ornek7 o=new Ornek7();
		System.out.println("Karenin Alan�"+o.alan(a));
		System.out.println("Karenin �evresi="+o.cevre(a));
	}

}
