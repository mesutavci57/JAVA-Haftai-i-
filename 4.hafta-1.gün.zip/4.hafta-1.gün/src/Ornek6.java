import java.util.Scanner;

public class Ornek6 {
	public float alan(float yaricap)
	{
		return (float)Math.PI*(yaricap*yaricap);
	}
	public float cevre(float yaricap)
	{
		return (float)(2*Math.PI*yaricap);
	}
	public static void main(String[] args) {
		//metod ile daire alan ve �evre hesaplamas�
		Scanner s=new Scanner(System.in);
		System.out.println("Yar��ap� giriniz");
		float r=s.nextFloat();
		Ornek6 o=new Ornek6();
		System.out.println("Dairenin Alan�="+o.alan(r));
		System.out.println("Dairenin �evresi="+	o.cevre(r));

	}

}
