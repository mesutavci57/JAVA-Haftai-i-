
public class Ornek2 {
public void ad(String ad)
{
	System.out.println(ad);
}
public void soyad(String soyad)
{
	System.out.println(soyad);
}
public void adSoyad(String ad,String soyad)
{
	System.out.println(ad+" "+soyad);
}
public void adSoyad(String adSoyad)
{
	System.out.println(adSoyad);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ornek2 o=new Ornek2();
		o.ad("Mesut");
		o.soyad("Avc�");
		o.adSoyad("Mesut", "Avc�");
		o.adSoyad("Mesut Avc�");
	}

}
