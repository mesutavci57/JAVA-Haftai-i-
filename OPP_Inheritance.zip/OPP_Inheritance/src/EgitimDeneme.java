
public class EgitimDeneme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Egitim e=new Egitim();
		e.mufredat();
		e.materyaller();
		System.out.println("-----------");
		Ogrenci ogrenci=new Ogrenci();
		ogrenci.dersler();
		ogrenci.sinif(2);
		ogrenci.mufredat();
		ogrenci.materyaller();
		System.out.println("-----------");
		Ogretmen ogretmen=new Ogretmen();
		ogretmen.dersler();
		ogretmen.adSoyad("Mesut","Avc�");
		ogretmen.mufredat();
		ogretmen.materyaller();
	}

}
