
public class Kedigil extends Hayvan {
public void vahsiOl()
{
	System.out.println("Kedigil Vah�ile�ti");
}
public void yemekYe()
{
	System.out.println("Kedigil yemek yedi");
}
public void sesCikar()
{
	System.out.println("Kedigil ses ��akrd�");
}
public void kosmaHizi(int hiz)
{
	System.out.println("Kedigil in ko�ma h�z�="+hiz);
}
}
