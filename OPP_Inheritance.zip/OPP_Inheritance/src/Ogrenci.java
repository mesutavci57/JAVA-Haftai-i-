
public class Ogrenci extends Egitim {
public void dersler()
{
	System.out.println("��rencinin dersleri");
}
public void sinif(int sinif)
{
	System.out.println("Ogrencinin sinifi="+sinif);
}
}
