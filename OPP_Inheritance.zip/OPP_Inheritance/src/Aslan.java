
public class Aslan extends Kedigil {
	public void vahsiOl()
	{
		System.out.println("Aslan vah�ile�ti");
	}
	public void sesCikar()
	{
		System.out.println("Aslan ses ��kard�");
	}
	public void kosmaHizi(int hiz)
	{
		System.out.println("Aslan�n kosma h�z�="+hiz);
	}
}
