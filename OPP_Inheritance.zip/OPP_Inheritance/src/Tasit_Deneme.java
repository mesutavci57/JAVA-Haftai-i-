import java.util.ArrayList;

public class Tasit_Deneme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<MotorluTasitlar> tasitlar=new ArrayList<>();
		tasitlar.add(new Araba(4,"K�rm�z�",2000,1,"Mercedes",1));
		tasitlar.add(new Kamyon(6,"Beyaz",1500,0,"Volvo",0));
		tasitlar.add(new Tir(8,"Ye�il",3000,0,"Scana",1));
		tasitlar.add(new SUV(4,"Lacivert",2000,0,"LandRover",2));
		for(MotorluTasitlar tasit:tasitlar)
		{
			System.out.println("Marka="+tasit.getMarka());
			System.out.println("Renk="+tasit.getRenk());
			System.out.println("Tekerlek say�s�="+tasit.getTekerlekSayisi());
			System.out.println("Vites T�r�="+tasit.getVitesTuru());
			System.out.println("Yak�t T�r�="+tasit.getYakitTuru());
			System.out.println("Beygit G�c�="+tasit.getBeygirGucu());
			tasit.yolcuSayisi();
			System.out.println("-----------------");
			
			if(tasit instanceof Araba)
			{
				Araba araba=(Araba)tasit;
				araba.yolcuSayisi();
			}
			/*
			 * ArrayList e eklenen de�erlerin farkl� tipte oldu�unu biliyorsak ilgili �st s�n�f�n de�erlerini �a��rmak isteyebiliriz
			 * 
			 * instanceof kelimesi sayesinde iki s�n�f�n ayn� tiplerde olup olmad���n� sorgular�z bu bize boolean de�er d�ner
			 * e�er tipler ayn� ise bir s�n�f� farkl� bir s�n�fa �evirebilirsiniz.(T�r d�n���m� yapabiliriz./casting i�lemi)
			 * 
			 * bu sayede cast etti�imiz s�n�ftaki �zellikleri ayr�ca g�rebiliriz.
			 */
		}
		//Bir ArrayList e s�n�f tiplerini farkl� olmas�na ra�men de�erleri ekleyebiliriz
		//Eklemek istedi�imiz nesnelerin(s�n�flar�n) miras al�nan �st s�n�f� �retti�imiz ArrayList tipindeyse
		//de�erleri eklememize olanak tan�n�r.
	}

}
