
public class Ogretmen extends Egitim{
	public void dersler()
	{
		System.out.println("��retmenin dersleri");
	}
	public void adSoyad(String ad,String soyad)
	{
		System.out.println("��retmenin adi="+ad+"��retmenin soyadi="+soyad);
	}
}
