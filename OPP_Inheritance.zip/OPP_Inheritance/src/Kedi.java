
public class Kedi extends Kedigil {
public void evcilOl()
{
	System.out.println("Kedi evcil oldu.");
}
public void sesCikar()
{
	System.out.println("Kedi ses ��kard�--Miyavv");
}
public void kosmaHizi(int hiz)
{
	System.out.println("Ko�ma H�z�="+hiz);
}
public void uyu()
{
	System.out.println("Kedi uyudu");
}
public void uyan()
{
	System.out.println("Kedi uyand�");
}
}
