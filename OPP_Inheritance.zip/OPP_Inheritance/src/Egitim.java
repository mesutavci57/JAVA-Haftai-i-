
public class Egitim {

	public void mufredat()
	{
		System.out.println("M�fredat �a�r�ld�");
	}
	public void materyaller()
	{
		System.out.println("Materyaller �a�r�ld�");
	}
}
