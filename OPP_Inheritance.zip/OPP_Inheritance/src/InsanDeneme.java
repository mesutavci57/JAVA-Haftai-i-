
public class InsanDeneme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Adem adem=new Adem();
		adem.avlan();
		adem.konus();
		adem.nefesAl();
		adem.uyu();
		adem.uyan();
		adem.yemekYe();
		
		System.out.println("-------------");
		
		Insan insan=new Insan();
		insan.iseGit();
		insan.arabaSur();
		insan.kitapOku();
		insan.sarkiSoyle();
		insan.avlan();
		insan.konus();
		insan.uyu();
		insan.uyan();
		insan.yemekYe();
		insan.nefesAl();
		
		
	}

}
