
public class Ogrenci {
	
	private int ogrenciNo;
	private int ogrenciSinif;
	private int okulaGirisYili;
	private int dogumYili;
	private double notOrtalamasi;
	private char cinsiyet;
	private String ogrenciAdSoyad;
	private String telefonNo;
	
	public Ogrenci() {
		
		
	}

	public Ogrenci(int ogrenciNo, int ogrenciSinif, int okulaGirisYili, int dogumYili, double notOrtalamasi,
			char cinsiyet, String ogrenciAdSoyad, String telefonNo) {
		//super();
		this.ogrenciNo = ogrenciNo;
		this.ogrenciSinif = ogrenciSinif;
		this.okulaGirisYili = okulaGirisYili;
		this.dogumYili = dogumYili;
		this.notOrtalamasi = notOrtalamasi;
		this.cinsiyet = cinsiyet;
		this.ogrenciAdSoyad = ogrenciAdSoyad;
		this.telefonNo = telefonNo;
	}

	public int getOgrenciNo() {
		return ogrenciNo;
	}

	public void setOgrenciNo(int ogrenciNo) {
		this.ogrenciNo = ogrenciNo;
	}

	public int getOgrenciSinif() {
		return ogrenciSinif;
	}

	public void setOgrenciSinif(int ogrenciSinif) {
		this.ogrenciSinif = ogrenciSinif;
	}

	public int getOkulaGirisYili() {
		return okulaGirisYili;
	}

	public void setOkulaGirisYili(int okulaGirisYili) {
		this.okulaGirisYili = okulaGirisYili;
	}

	public int getDogumYili() {
		return dogumYili;
	}

	public void setDogumYili(int dogumYili) {
		this.dogumYili = dogumYili;
	}

	public double getNotOrtalamasi() {
		return notOrtalamasi;
	}

	public void setNotOrtalamasi(double notOrtalamasi) {
		this.notOrtalamasi = notOrtalamasi;
	}

	public char getCinsiyet() {
		return cinsiyet;
	}

	public void setCinsiyet(char cinsiyet) {
		this.cinsiyet = cinsiyet;
	}

	public String getOgrenciAdSoyad() {
		return ogrenciAdSoyad;
	}

	public void setOgrenciAdSoyad(String ogrenciAdSoyad) {
		this.ogrenciAdSoyad = ogrenciAdSoyad;
	}

	public String getTelefonNo() {
		return telefonNo;
	}

	public void setTelefonNo(String telefonNo) {
		this.telefonNo = telefonNo;
	}

}
