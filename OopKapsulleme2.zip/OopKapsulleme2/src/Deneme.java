import java.util.ArrayList;

public class Deneme {

	public static void main(String[] args) {
		
		ArrayList<Ogrenci> bilMuhOgrenciler = new ArrayList<>();
		bilMuhOgrenciler.add (new Ogrenci (1,1,2019,2000,3.20,'k',"Ad Soyad - 1", "+9022115151"));
		bilMuhOgrenciler.add (new Ogrenci (2,1,2013,1990,3.30,'e',"Ad Soyad - 2", "+9022158522"));
		bilMuhOgrenciler.add (new Ogrenci (3,1,2013,1990,3.20,'k',"Ad Soyad - 3", "+9058121212"));
		bilMuhOgrenciler.add (new Ogrenci (4,1,2013,1990,3.20,'e',"Ad Soyad - 4", "+9022152151"));
		
		ArrayList<Ogrenci> elkMuhOgrenciler = new ArrayList<>();
		elkMuhOgrenciler.add (new Ogrenci (5,1,2019,2000,3.20,'k',"Ad Soyad - 5", "+9022115151"));
		
		ArrayList<Ders> dersler = new ArrayList<>();
		dersler.add(new Ders(8,4,"Java Programlama", "�erif G�ng�re", "Lab09",bilMuhOgrenciler ));
		dersler.add(new Ders(8,4,"Temel Elektronik", "Hoca Ad Soyad", "Lab01",elkMuhOgrenciler ));
		
		
		ArrayList<Bolum> bolumler = new ArrayList<>();
		bolumler.add(new Bolum ("Bilgisayar M�hendisli�i", 240, dersler, bilMuhOgrenciler)) ;
		bolumler.add(new Bolum ("Elektrik Elektronik  M�hendisli�i", 240, dersler, elkMuhOgrenciler)) ;
		
		ArrayList<Kampus> kampusler = new ArrayList<>();
		kampusler.add(new Kampus("Ayaza�a kapms�s�", "Adresi", bolumler));
		
		
		Bolum b = new Bolum();
		System.out.println(b.getBolumAdi());
		
		//ArrayList<Universite> universite = new ArrayList<>();
		//universite.add(new Universite("�stanbul Teknik �niversitesi", "T�rkiye", "02135651", kampusler));
		
		Universite universite = new Universite("�stanbul Teknik �niversitesi", "T�rkiye", "02135651", kampusler);
		 
		// it� ayaza�a kamps�s�n�n bilg m�h b�l�m�n�n java programlama dersinin ��rencilerini listele
		
		for(Ogrenci ogrenci : universite.getKapmpusler().get(0).getBolumler().get(0).getDersler().get(0).getOgrenciler()) {
			
			System.out.println("��rencinin ad� : "+ ogrenci.getOgrenciAdSoyad());
			System.out.println("��rencinin do�um y�l�l: "+ogrenci.getDogumYili());
		
		}
		
		
		

	}

}
