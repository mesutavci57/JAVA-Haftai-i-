import java.util.ArrayList;

public class Ders {

	private int haftaliksaat;
	private int kredi;
	private String dersAdi;
	private String ogretmenAdSoyad;
	private String sinifAdSoyad;
	private ArrayList<Ogrenci> ogrenciler;
	
	public Ders() {
		
		
	}

	public Ders(int haftaliksaat, int kredi, String dersAdi, String ogretmenAdSoyad, String sinifAdSoyad,
			ArrayList<Ogrenci> ogrenciler) {
		super();
		this.haftaliksaat = haftaliksaat;
		this.kredi = kredi;
		this.dersAdi = dersAdi;
		this.ogretmenAdSoyad = ogretmenAdSoyad;
		this.sinifAdSoyad = sinifAdSoyad;
		this.ogrenciler = ogrenciler;
	}

	public int getHaftaliksaat() {
		return haftaliksaat;
	}

	public void setHaftaliksaat(int haftaliksaat) {
		this.haftaliksaat = haftaliksaat;
	}

	public int getKredi() {
		return kredi;
	}

	public void setKredi(int kredi) {
		this.kredi = kredi;
	}

	public String getDersAdi() {
		return dersAdi;
	}

	public void setDersAdi(String dersAdi) {
		this.dersAdi = dersAdi;
	}

	public String getOgretmenAdSoyad() {
		return ogretmenAdSoyad;
	}

	public void setOgretmenAdSoyad(String ogretmenAdSoyad) {
		this.ogretmenAdSoyad = ogretmenAdSoyad;
	}

	public String getSinifAdSoyad() {
		return sinifAdSoyad;
	}

	public void setSinifAdSoyad(String sinifAdSoyad) {
		this.sinifAdSoyad = sinifAdSoyad;
	}

	public ArrayList<Ogrenci> getOgrenciler() {
		return ogrenciler;
	}

	public void setOgrenciler(ArrayList<Ogrenci> ogrenciler) {
		this.ogrenciler = ogrenciler;
	}
	
}
