import java.util.ArrayList;

public class Universite {
	
	private String ad;
	private String ulke;
	private String telefonNo;
	private ArrayList<Kampus> kapmpusler;
	
	public Universite() {
		
		
	}

	public Universite(String ad, String ulke, String telefonNo, ArrayList<Kampus> kapmpusler) {
		super();
		this.ad = ad;
		this.ulke = ulke;
		this.telefonNo = telefonNo;
		this.kapmpusler = kapmpusler;
	}

	public String getAd() {
		return ad;
	}

	public void setAd(String ad) {
		this.ad = ad;
	}

	public String getUlke() {
		return ulke;
	}

	public void setUlke(String ulke) {
		this.ulke = ulke;
	}

	public String getTelefonNo() {
		return telefonNo;
	}

	public void setTelefonNo(String telefonNo) {
		this.telefonNo = telefonNo;
	}

	public ArrayList<Kampus> getKapmpusler() {
		return kapmpusler;
	}

	public void setKapmpusler(ArrayList<Kampus> kapmpusler) {
		this.kapmpusler = kapmpusler;
	}
	

}
