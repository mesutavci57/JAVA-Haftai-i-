import java.util.ArrayList;

public class Ornek4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String>liste=new ArrayList<>();
		liste.add("Mesut");
		liste.add("Ekrem");
		liste.add("Bahri");
		liste.add("Yavuz");
		
		for(String eleman:liste)
		{
			System.out.println(eleman);
		}
		System.out.println("Listeden bahri de�erini silelim");
		String silinecekKelime="Bahri";//String de�er ile eleman� silip listeyi tekrardan yazd�rd�k
		liste.remove(silinecekKelime);
		for(String eleman:liste)
		{
			System.out.println(eleman);
		}
	}

}
