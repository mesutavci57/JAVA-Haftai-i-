import java.util.ArrayList;
import java.util.Scanner;

public class Ornek3 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		ArrayList<Integer>liste=new ArrayList<>();
		System.out.println("Ka� adet say� gireceksiniz");
		int sayi=s.nextInt();
		for(int i=0;i<sayi;i++)
		{
			System.out.println("Say� gir");
			liste.add(s.nextInt());
		}
		System.out.println("0-4 aras� bir say� gir");
		int deger=s.nextInt();
		liste.remove(deger);
		for(int i=0;i<liste.size();i++)
		{
			System.out.println(liste.get(i));
		}

	}

}
