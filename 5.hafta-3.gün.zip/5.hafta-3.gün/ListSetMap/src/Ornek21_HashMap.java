import java.util.HashMap;
import java.util.Scanner;

public class Ornek21_HashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		HashMap<Integer,String> degerler=new HashMap<>();
		for(int i=0;i<5;i++)
		{
			System.out.println("Posta kodu giriniz");
			int posta=s.nextInt();
			System.out.println("il�e giriniz");
			String ilce=s.next();
			degerler.put(posta,ilce);
		}

			System.out.println(degerler.values());
			System.out.println(degerler.keySet());
	}

}
