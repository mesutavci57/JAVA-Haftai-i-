import java.util.LinkedList;
import java.util.Queue;

public class Ornek17_Queue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Queue metodlar�
		/*
		 * add(eleman): Parametrede verilen eleman� kuyru�a ekler. ��lemin ba�ar�s�z olmas� durumunda hata f�rlat�r.
		 * offer(eleman): Parametrede verilen eleman� kuyru�a ekler. ��lemin ba�ar�s�z olmas� durumunda null d�ner.
		 * poll(): Kuyru�un ba��ndaki eleman� kuyruktan ��kart�r.
		 * peek(): Kuyrukta s�radaki elemana ula�mak i�in kullan�l�r.
		 */
		Queue<Object>kuyruk=new LinkedList<>();
		kuyruk.add("�SMEK");
		kuyruk.add("FAT�H");
		kuyruk.add("B�L���M");
		kuyruk.add("OKULU");
		kuyruk.add("JAVA8");
		kuyruk.offer(1);
		for(Object eleman:kuyruk)
		{
			System.out.println(eleman);
		}
		System.out.println("Kuyru�un ilk eleman�="+kuyruk.peek());
		kuyruk.poll();//ilk eleman silindi.
		for(Object eleman:kuyruk)
		{
			System.out.println(eleman);
		}
		System.out.println("Kuyru�un ilk eleman�="+kuyruk.peek());
		
	}

}
