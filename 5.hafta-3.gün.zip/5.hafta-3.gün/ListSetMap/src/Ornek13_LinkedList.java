import java.util.LinkedList;

public class Ornek13_LinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//LinkedList metodlar
		/*add--eleman ekler.
		 * addFirst--en ba�a ekler
		 * addLast--en sona ekler
		 * clear--T�m elemanlar� temizler.
		 * contains--listede eleman varl��� sorgusu yapar
		 * clone--liste elemanlar�n� ba�ka listeye kopyalamay� sa�lar
		 * getFirst
		 * getLast
		 * indexOf
		 * lastIndexOf
		 * iterator
		 * listIterator
		 * remove
		 * removeFirst
		 * removeLast
		 */
		
		LinkedList<String>liste=new LinkedList<>();
		liste.add("Mercedes");
		liste.add("Audi");
		liste.add("Bmw");
		liste.addFirst("PORSCHE");
		liste.addLast("Murat 131");
		for(String eleman:liste)
		{
			System.out.println(eleman);
		}
		System.out.println("Birinci eleman="+liste.getFirst());
		System.out.println("Sonuncu eleman="+liste.getLast());
		//ilk ve son eleman� silelim.
		liste.removeFirst();
		liste.removeLast();
		System.out.println("Birinci eleman="+liste.getFirst());
		System.out.println("Sonuncu eleman="+liste.getLast());
	}

}
