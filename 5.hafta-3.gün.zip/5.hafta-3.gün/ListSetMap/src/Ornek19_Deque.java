import java.util.Deque;
import java.util.LinkedList;

public class Ornek19_Deque {

	public static void main(String[] args) {
	Deque sayilar=new LinkedList();
	sayilar.addFirst(10);
	sayilar.add(50);
	sayilar.add(40);
	sayilar.add(150);
	for(int i=0;i<4;i++)
	{
		System.out.println(sayilar.peekFirst());
		sayilar.poll();
		
	}

	}

}
