import java.util.Vector;

public class Ornek11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<String>vector=new Vector<>(3);
		vector.setSize(2);//2 eleman boyutu daha ekledik.
		vector.addElement("�erif");
		vector.addElement("istanbul");
		vector.addElement("Yaz�l�m Geli�tiricisi");
		for(String eleman:vector)
		{
			System.out.println(eleman);
		}
		System.out.println("Capacity:"+vector.capacity());//vector un kapasitesini g�sterir.bir de�er verilmemi� ise varsay�lan de�er 10 dur.biz 3 eleman kapasitesi tan�mlad�k.
		//Belirtti�imiz kapasite �rne�in 3 ise 4.elemana gelince ayr� bir 3 elemanl�k yer a�ar.
		System.out.println("Size:"+vector.size());
		/*
		 * addElement()--veri eklemek i�in kullan�l�r.
		 * capacity()
		 * clear()--de�erleri temizler.
		 * contains()--Listede de�er aramak i�in kullan�l�r.
		 * get()--indisini bildi�imiz de�eri �a��r�r(ilk bulunan)
		 * indexOf()--indisini bildi�imiz de�erin indisini �a��rmak i�in kullan�l�r.(ilk bulunan)
		 * lastIndexOf()--indisini bildi�imiz de�eri indisini �a��rmak i�in kullan�l�r(son bulunan)
		 * removeAllElements--t�m elemanlar� silmek i�in kullan�l�r
		 * set var olan de�erleri de�i�tirmek i�in kullan�l�r.
		 * remove()---belirtilen indis yada isimdeki de�eri siler.
		 * size--vector un eleman say�s�n� verir. 
		 */
	}

}
