import java.util.Stack;

public class Ornek16_Stack {

	public static void main(String[] args) {
		Stack stack=new Stack();
		stack.push("MECL�S�");
		stack.push("M�LLET");
		stack.push("B�Y�K");
		stack.push("T�RK�YE");
		System.out.println(stack);

	}

}
