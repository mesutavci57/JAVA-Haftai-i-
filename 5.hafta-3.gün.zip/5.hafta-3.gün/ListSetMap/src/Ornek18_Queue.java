import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Ornek18_Queue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<String> kuyruk=new LinkedList<>();
		Scanner s=new Scanner(System.in);
		for(int i=0;i<2;i++)
		{
			System.out.println("Kuyru�a eklenecek eleman� ekleyin");
			String str=s.next();
			if(kuyruk.add(str))
			{
				
				System.out.println("De�er ba�ar�yla eklendi "+str+"\n");
			}
		}
		kuyruk.poll();
		for(String string:kuyruk)
		{
			System.out.println(string);
		}
	}

}
