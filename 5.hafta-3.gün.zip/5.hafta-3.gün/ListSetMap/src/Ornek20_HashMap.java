import java.util.HashMap;
import java.util.Scanner;

public class Ornek20_HashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner s=new Scanner(System.in);
	HashMap<String,String>map=new HashMap<>();
	System.out.println("Ka� adet deger girilecek");
	int n=s.nextInt();
	for(int i=0;i<n;i++)
	{
		System.out.println("Key giriniz");
		String key=s.next();
		System.out.println("Kelime gir");
		String kelime=s.next();
		map.put(key, kelime);
	}
	System.out.println("aranan keyi giriniz");
	String aranan=s.next();
	if(map.containsKey(aranan))
	{
		System.out.println(map.get(aranan));
	}
	else
	{
		System.out.println("Aranan keye ait de�er bulunamad�");
	}
	}

}
