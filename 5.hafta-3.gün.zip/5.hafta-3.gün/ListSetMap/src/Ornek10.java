import java.util.ArrayList;
import java.util.Random;

public class Ornek10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rnd=new Random();
		ArrayList<Integer>sayilar=new ArrayList<>();
		for (int i = 0; i <10; i++) {
			sayilar.add(rnd.nextInt(5000));
		}
		Object[] intDizi=sayilar.toArray();
		for(Object sayi:intDizi)
		{
			System.out.println(sayi);
		}
		System.out.println("-----------------");
		ArrayList<String>dersler=new ArrayList<>();
		dersler.add("Java");
		dersler.add("Android");
		dersler.add("Google Seo");
		dersler.add("Wordpress");
		dersler.add("E-Ticaret");
		dersler.add("PHP");
		dersler.add("ASP.NET");
		dersler.add("C#");
		dersler.add("Java");
		int index=dersler.indexOf("PHP");
		System.out.println(index);
		int lastIndex=dersler.lastIndexOf("Java");
		System.out.println(lastIndex);
		if(dersler.contains("E-Ticaret"))
		{
			System.out.println("Listede E-Ticaret vard�r.");
		}
		else
		{
			System.out.println("Listede E-Ticaret yoktur.");
		}
	}

}
