import java.util.ArrayList;

public class Ornek9 {

	public static void main(String[] args) {
		ArrayList<String>meyveler=new ArrayList<>();
		meyveler.add("Elma");
		meyveler.add("�ilek");
		meyveler.add("Nar");
		meyveler.add("Kavun");
		meyveler.add("Kiraz");
		for(String eleman:meyveler)//elemanlar listelendi
		{
			System.out.println(eleman);
		}
		for(int i=0;i<meyveler.size();i++)
		{
			System.out.println(meyveler.get(i));
		}
		meyveler.remove("�ilek");//�ilek eleman�n� sildik
		for(String meyve:meyveler)
		{
			System.out.println(meyve);
		}
		meyveler.clear();//Elemanlar� sildik
		if(meyveler.isEmpty())//Listenin bo�mu yoksa dolu mu oldu�unu kontrol ettik
		{
			System.out.println("Meyveler listesi bo�tur");
		}
		else
		{
			System.out.println("Meyveler listesi doludur.");
		}

	}

}
